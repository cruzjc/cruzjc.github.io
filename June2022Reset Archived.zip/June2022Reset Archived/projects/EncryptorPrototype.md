---
layout: project
type: project
image: images/EncryptorScreenShot.png
title: Encryptor mini-pre-project idea
permalink: projects/EncryptorPrototype
date: 2016
labels:
  - Java
  - encryption
  - ics111
summary: An encryptor prototype
---

<div class="ui small rounded images">
  <img class="ui image" src="../images/EncryptorScreenShot.png" width="300">
</div>


This was a small working prototype of an encryptor i worked on while in ics111. While coming up with list of ideas for a group project to throw out to the rest of the class, making some sort of file encryptor was one of them. I threw out this idea and the undertale tile puzzle idea out to the class but only one person was interested in the undertale puzzle.

I am quite suprised by how easy it is to mess up a file with a few lines of code. One thing I find fascinating is seeing how something that seems soo chaotic turn into something so ordered and meaningful. All this code does is just flip the data. You run this with a text file and try to open it, it will look like all sorts of messed up. Run it again though with the same file, and its back to what would be considered "normal".


Source files
https://github.com/cruzjc/Encryptor


