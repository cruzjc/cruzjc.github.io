---
layout: project
type: project
image: images/2017-01-20 (1).png
title: Undertale Tile Puzzle
permalink: projects/Undertale Tile Puzzle
date: 2016
labels:
  - Java
  - Undertale
  - ics111
summary: A ics111 group project based on the game Undertale
---

<div class="ui small rounded images">
  <img class="ui image" src="../images/2017-01-20 (1).png" width="500">
</div>

<div class="ui small rounded images">
  <img class="ui image" src="../images/Undertale tile puzzle.png" width="500">
</div>

The Undertale Tile Puzzle is an Ics111 group project created using Eclipse and a multimedia library (EZ graphics by Dylan Kobayashi). This was based on a game me and my partner both enjoyed named Undertale.
The simple goal is to reach the other size of the randomly generated tile puzzle while avoiding tile hazards and dodging monsters.

I had a lot of fun while working on this game along with my partner primarily because it came with a motivation to learn anything about java to do what I wanted it to do. I am particulary proud of getting multiple threads to run even if it wasn't part of the curriculum nor part of improving the gameplay experience. It isn't as polished as I would like it to be mainly because it was a frantic coding jam before the deadline to add a more meaty gameplay (adding in more monsters/classes and programming specific "bullet" patterns) but it was an experience that I learned a lot from.

A video showing some gameplay is posted on youtube 
https://www.youtube.com/watch?v=A6OgEHcgTpE&t=90s


A link to the source files (except for sounds)
https://github.com/cruzjc/UndertaleTilePuzzle



