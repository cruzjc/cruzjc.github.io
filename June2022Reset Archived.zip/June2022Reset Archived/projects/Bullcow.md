---
layout: project
type: project
image: images/2017-01-20 (2).png
title: Bullcow
permalink: projects/bullcow
date: 2016
labels:
  - C++
  - Text-console game
  - Unreal engine tutorial
summary: A small simple game made as part of a tutorial for learning the Unreal Engine
---

<div class="ui small rounded images">
  <img class="ui image" src="../images/2017-01-20 (2).png">
</div>

In part of my spare time I have taken an interest in learning how to use the unreal engine. I came across a tutorial on the basics of the unreal engine and as a part of the learning process, it involved also learning the basics of C++ through visual studio. What resulted is a small text console game where you try to guess an isogram.

Going through this gave me some practice on the C++ language. I've tried learning C++ before on my own however the idea of pointers always gave me a headache. I think I have a better understanding now since I have written some code that make some use of it. 

Github source https://github.com/cruzjc/BullCowProject
